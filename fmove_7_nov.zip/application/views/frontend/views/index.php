<!--Slider-->
<div class="rev_slider_wrapper">
  <div id="rev_eight" class="rev_slider"  data-version="5.0">
    <ul>
      <!-- SLIDE  -->
      <li data-transition="fade">
        <img src="<?= $assets ?>img/home8-banner1.jpg" alt="" data-bgposition="center center" data-bgfit="cover">
        <div class=" tp-caption tp-resizeme"
          data-start="1300"
          data-x="['left','center','center','center']" data-hoffset="['0','0','0','15']" 
          data-y="['center','center','center','center']" data-voffset="['0','0','0','0']" 
          data-responsive_offset="on" 
          data-transform_idle="o:1;"
          data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" 
          data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;">
          <p class="topper">£8,600 Per Month - Apartment</p>
          <div class="white_cap">
            <div class="price">For Rent</div>
            <div class="white_cont bottom10">
              <h3 class="bottom10 top15">Park Avenue Apartment</h3>
              <p class="bottom15">Lorem ipsum dolor sit amet, adipiscing elit, <br> sed diam power...</p>
              <a class="btn-more" href="contactus">
                <i><img src="<?= $assets ?>img/arrowl.png" alt="arrow"></i>
                <span>Contact Me</span>
                <i><img src="<?= $assets ?>img/arrowr.png" alt="arrow"></i>
              </a>
            </div>
            <div class="property_meta clearfix">
              <div class="col-xs-6"><span><i class="icon-select-an-objecto-tool"></i>4800 sq ft</span></div>
              <div class="col-xs-6"><span><i class="icon-bed"></i>3 Bedrooms</span> </div>
            </div>
            <div class="property_meta clearfix">
              <div class="col-xs-6"><span><i class="icon-pool-stairs"></i>Swimming Pool</span> </div>
              <div class="col-xs-6"><span><i class="icon-garage"></i>1 Garage</span></div>
            </div>
            <div class="bottom_text top10">
              <p> <i class="icon-icons74"></i>London, United Kingdom</p>
            </div>
          </div>
        </div>
      </li>
      <li data-transition="fade">
        <img src="<?= $assets ?>img/home8-banner2.jpg" alt="" data-bgposition="center center" data-bgfit="cover">
        <div class="tp-caption tp-resizeme"
          data-x="['left','center','center','center']" data-hoffset="['0','0','0','15']" 
          data-y="['center','center','center','center']" data-voffset="['0','0','0','0']" 
          data-responsive_offset="on"
          data-start="1300"
          data-transform_idle="o:1;"
          data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" 
          data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;">
          <p class="topper">£8,zcxvzxv600 Per Month - Apartment</p>
          <div class="white_cap">
            <div class="price">For Rent</div>
            <div class="white_cont bottom10">
              <h3 class="bottom10 top15">Park Avenue Apartment</h3>
              <p class="bottom15">Lorem ipsum dolor sit amet, adipiscing elit, <br> sed diam power...</p>
              <a class="btn-more" href="contactus">
                <i><img src="<?= $assets ?>img/arrowl.png" alt="arrow"></i>
                <span>Contact Me</span>
                <i><img src="<?= $assets ?>img/arrowr.png" alt="arrow"></i>
              </a>
            </div>
            <div class="property_meta clearfix">
              <div class="col-xs-6"><span><i class="icon-select-an-objecto-tool"></i>4800 sq ft</span></div>
              <div class="col-xs-6"><span><i class="icon-bed"></i>3 Bedrooms</span> </div>
            </div>
            <div class="property_meta clearfix">
              <div class="col-xs-6"><span><i class="icon-pool-stairs"></i>Swimming Pool</span> </div>
              <div class="col-xs-6"><span><i class="icon-garage"></i>1 Garage</span></div>
            </div>
            <div class="bottom_text top10">
              <p> <i class="icon-icons74"></i>Bayonne, New Jersey</p>
            </div>
          </div>
        </div>
      </li>
      <li data-transition="fade">
        <img src="<?= $assets ?>img/home8-banner3.jpg" alt="" data-bgposition="center center" data-bgfit="cover">
        <div class="tp-caption tp-resizeme"
          data-x="['left','center','center','center']" data-hoffset="['0','0','0','15']" 
          data-y="['center','center','center','center']" data-voffset="['0','0','0','0']" 
          data-responsive_offset="on"
          data-start="1300"
          data-transform_idle="o:1;"
          data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" 
          data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;">
          <p class="topper">£8asdf,600 Per Month - Apartment</p>
          <div class="white_cap">
            <div class="price">For Rent</div>
            <div class="white_cont bottom10">
              <h3 class="bottom10 top15">Park Avenue Apartment</h3>
              <p class="bottom15">Lorem ipsum dolor sit amet, adipiscing elit, <br> sed diam power...</p>
              <a class="btn-more" href="contactus">
                <i><img src="<?= $assets ?>img/arrowl.png" alt="arrow"></i>
                <span>Contact Me</span>
                <i><img src="<?= $assets ?>img/arrowr.png" alt="arrow"></i>
              </a>
            </div>
            <div class="property_meta clearfix">
              <div class="col-xs-6"><span><i class="icon-select-an-objecto-tool"></i>4800 sq ft</span></div>
              <div class="col-xs-6"><span><i class="icon-bed"></i>3 Bedrooms</span> </div>
            </div>
            <div class="property_meta clearfix">
              <div class="col-xs-6"><span><i class="icon-pool-stairs"></i>Swimming Pool</span> </div>
              <div class="col-xs-6"><span><i class="icon-garage"></i>1 Garage</span></div>
            </div>
            <div class="bottom_text top10">
              <p> <i class="icon-icons74"></i>Bayonne, New Jersey</p>
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</div>
<!--Slider ends-->




        
<!-- Property Search area Start -->
<section class="property-query-area">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <h2 class="uppercase">Advanced Search</h2>
        <p class="heading_space"> We have Properties in these Areas View a list of Featured Properties.</p>
      </div>
    </div>
    <form class="callus" action="search?type=prop" method="POST">
    <div class="row">
       <div class="col-md-3 col-sm-6">
          <div class="single-query form-group">
            <input type="text" class="keyword-input" name="keyword" placeholder="Keyword (e.g. 'office')">
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="single-query form-group">
            <div class="intro town_dtl">
              <select name="town_id">
                <option value="">Select Town</option>
                <?php 
                
                foreach($defdata['all_uk_towns'] as $uk_town)
                {
                  $selected = ($uk_town['postcode'] == $this->input->post('town_id')) ? ' selected="selected"' : "";

                  echo '<option value="'.$uk_town['postcode'].'" '.$selected.'>'.$uk_town['postcode'].','.$uk_town['town'].', '.$uk_town['region'].', '.$uk_town['uk_region'].'.</option>';
                } 
                ?>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="single-query form-group">
            <div class="intro">
              <select name="prop_type">
                <option value="" class="active">Select Type</option>
                <option value="bus">Business</option>
                <option value="com">Commercial</option>
                <option value="res">Residential</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="single-query form-group">
            <div class="intro">
              <select name="prop_stat">
                <option value="" class="active">Select Status</option>
                <option value="sale">For Sale</option>
                <option value="rent">For Rent</option>
                <option value="salag">Sale Agreed</option>
                <option value="renag">Rent Agreed</option>
                <option value="sold">Sold</option>
                <option value="rentd">Rented</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="row ">
            <div class="col-md-6 col-sm-6">
              <div class="single-query form-group">
                <div class="intro">
                  <select name="bed">
                    <option value="" class="active">Min. Beds</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-sm-6">
              <div class="single-query form-group">
                <div class="intro">
                  <select name="bath">
                    <option value="" class="active">Min Baths</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="row">
            <div class="col-sm-6">
              <div class="single-query form-group">
                <input type="text" name="min_area" class="keyword-input" placeholder="Min Area (sq ft)">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="single-query form-group">
                <input type="text" name="max_area" class="keyword-input" placeholder="Max Area (sq ft)">
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-8">
              <div class="col-md-6 col-sm-6">
              <div class="single-query form-group">
                <div class="intro">
                  <select name="min_price">

                    <option value="" class="active">Price (Min)</option>
                    <option value="10000">£ 10000</option>
                    <option value="20000">£ 20000</option>
                    <option value="30000">£ 30000</option>
                    <option value="40000">£ 40000</option>
                    <option value="50000">£ 50000</option>
                    <option value="60000">£ 60000</option>
                    <option value="70000">£ 70000</option>
                    <option value="80000">£ 80000</option>
                    <option value="90000">£ 90000</option>
                    <option value="100000">£ 100000</option>
                    <option value="110000">£ 110000</option>
                    <option value="120000">£ 120000</option>
                    <option value="130000">£ 130000</option>
                    <option value="140000">£ 140000</option>
                    <option value="150000">£ 150000</option>
                    <option value="175000">£ 175000</option>
                    <option value="200000">£ 200000</option>
                    <option value="250000">£ 250000</option>
                    <option value="300000">£ 300000</option>
                    <option value="350000">£ 350000</option>
                    <option value="400000">£ 400000</option>
                    <option value="450000">£ 450000</option>
                    <option value="500000">£ 500000</option>
                    <option value="600000">£ 600000</option>
                    <option value="700000">£ 700000</option>
                    <option value="800000">£ 800000</option>
                    <option value="900000">£ 900000</option>
                    <option value="1000000">£ 1000000</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-sm-6">
              <div class="single-query form-group">
                <div class="intro">
                  <select name="max_price">
                    <option value="" class="active">Price (Max)</option>
                    <option value="10000">£ 10000</option>
                    <option value="20000">£ 20000</option>
                    <option value="30000">£ 30000</option>
                    <option value="40000">£ 40000</option>
                    <option value="50000">£ 50000</option>
                    <option value="60000">£ 60000</option>
                    <option value="70000">£ 70000</option>
                    <option value="80000">£ 80000</option>
                    <option value="90000">£ 90000</option>
                    <option value="100000">£ 100000</option>
                    <option value="110000">£ 110000</option>
                    <option value="120000">£ 120000</option>
                    <option value="130000">£ 130000</option>
                    <option value="140000">£ 140000</option>
                    <option value="150000">£ 150000</option>
                    <option value="175000">£ 175000</option>
                    <option value="200000">£ 200000</option>
                    <option value="250000">£ 250000</option>
                    <option value="300000">£ 300000</option>
                    <option value="350000">£ 350000</option>
                    <option value="400000">£ 400000</option>
                    <option value="450000">£ 450000</option>
                    <option value="500000">£ 500000</option>
                    <option value="600000">£ 600000</option>
                    <option value="700000">£ 700000</option>
                    <option value="800000">£ 800000</option>
                    <option value="900000">£ 900000</option>
                    <option value="1000000">£ 1000000</option>
                  </select>
                </div>
              </div>
            </div>
            </div>
            <div class="col-md-4 text-right form-group">

              <input name="type" type="hidden" value="prop">
              <button type="submit" class="btn-blue border_radius ">Search</button>
            </div>
          </div>
        </div>
 
    </div>
    <div class="group-button-search">
      <a data-toggle="collapse" href=".search-propertie-filters" class="more-filter">
        <i class="fa fa-plus text-1" aria-hidden="true"></i><i class="fa fa-minus text-2 hide" aria-hidden="true"></i>
        <div class="text-1">Show more search options</div>
        <div class="text-2 hide">less more search options</div>
      </a>
    </div>
    <div class="search-propertie-filters collapse">
      <div class="container-2">
        <div class="row">
          <!-- <div class="col-md-3 col-sm-3 col-xs-4">
            <div class="search-form-group white">
              <input type="checkbox" name="check-box" />
              <span>Air Conditioning</span>
            </div>
          </div> -->
          <div class="col-md-3 col-sm-3 col-xs-4">
            <div class=" white">
              <input type="checkbox" name="AC" value="1">
              <span>Air Conditioning</span>
            </div>
          </div> 
          <div class="col-md-3 col-sm-3 col-xs-4">
            <div class=" white">
              <input type="checkbox" name="bbq" value="1">
              <span>Barbeque Grill</span>
            </div>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-4">
            <div class=" white">
              <input type="checkbox" name="Balcony" value="1">
              <span>Balcony</span>
            </div>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-4">
            <div class="white">
              <input type="checkbox" name="Laundry" value="1">
              <span>Laundry</span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 col-sm-3 col-xs-4">
            <div class="white">
              
                <input name="Theater" type="checkbox" value="1"> 
                <span>Theater</span>
            </div>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-4">
            <div class="white">
              <input type="checkbox" name="Lawn" value="1">
              <span>Lawn</span>
            </div>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-4">
            <div class="white">
              <input type="checkbox" name="Basement" value="1">
              <span>Basement</span>
            </div>
          </div>
          
        </div>
      </div>
    </div>
         </form>
  </div>
</section>
<!-- Property Search area End -->


<!-- Latest Property -->
<section id="property" class="padding index2 bg_light">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 text-center">
        <h2 class="uppercase">PROPERTY LISTINGS</h2>
        <p class="heading_space"> We are proud to present to you some of the best homes, apartments, offices e.g. 
        across United Kingdom for affordable prices. </p>
      </div>
    </div>
    
    <div class="row"> <?php ?>
      <?php 
      
      foreach($defdata['home_prop'] as $prop){?> 
      <div class="col-sm-6 col-md-4">
        <div class="property_item heading_space">
          <div class="property_head
          <?php if ($prop['is_feat'] == "1")
              { 
                echo "fea_color";
              }
              else if ($prop['status'] == "rent" || $prop['status'] == "sale")
              {
                echo "rs_clr";
              }
              else if ($prop['status'] == "sold" || $prop['status'] == "rentd")
              {
                echo "sdr_clr";
              }
               else if ($prop['status'] == "salag" || $prop['status'] == "rentag")
              {
                echo "ag_clr";
              }



              ?>
           text-center">
             <h3 class="captlize"><a href="property_detail?id=<?= $prop['prop_id'] ?>"><?= $prop['title'] ?></a></h3>
             <p><?= $prop['address'] ?></p>
          </div>
          <div class="image proprties_images"> 
            <a href="property_detail?id=<?= $prop['prop_id'] ?>"><img src="<?= $assets."img/properties/".$prop['prop_id'] ?>/cover.jpg" alt="property1" class="img-responsive"></a>
            <div class="price clearfix"> 
            <span class="tag pull-right"><?php
             if ($prop['status'] == "sale")
              {
                echo "For Sale";
              }
              else if ($prop['status'] == "rent")
              {
                echo "For Rent";
              }
               else if ($prop['status'] == "salag" )
              {
                echo "Sale Agreed";
              }
              else if ($prop['status'] == "rentag")
              {
                echo "Rent Agreed";
              }
              else if ($prop['status'] == "sold" )
              {
                echo "Sold";
              }
              else if ($prop['status'] == "rentd")
              {
                echo "Rented";
              }


             ?></span>
          </div> 
          </div>
          <div class="proerty_content ">
            <div class="property_meta <?php if ($prop['is_feat'] == "1")
              {
                echo "fea_color";
              }
              else if ($prop['status'] == "rent" || $prop['status'] == "sale")
              {
                echo "rs_clr";
              }
              else if ($prop['status'] == "sold" || $prop['status'] == "rentd")
              {
                echo "sdr_clr";
              }
               else if ($prop['status'] == "salag" || $prop['status'] == "rentag")
              {
                echo "ag_clr";
              }



              ?>"> 
              <span><i class="icon-select-an-objecto-tool"></i><?= $prop['prop_details']['area'] ?>sq ft</span> 
              <span><i class="icon-bed"></i><?= $prop['prop_details']['bedrooms']?> Bedrooms</span> 
              <span><i class="icon-safety-shower"></i><?= $prop['prop_details']['bathrooms']?> Bathrooms</span>   
            </div>
            <div class="proerty_text">
              <p><?= $prop['excerpt'] ?>…</p>
            </div>
            <div class="favroute clearfix">
              <p class="pull-md-left">£ <?= $prop['price'] ?></p>
              <ul class="pull-right">
                <li><a href="#."><i class="icon-like"></i></a></li>
                <!-- <li><a href="#one" class="share_expender" data-toggle="collapse"><i class="icon-share3"></i></a></li> -->
              </ul>
            </div>
            <div class="toggle_share collapse" id="one">
              <ul>
                <li><a href="#." class="facebook"><i class="icon-facebook-1"></i> Facebook</a></li>
                <li><a href="#." class="twitter"><i class="icon-twitter-1"></i> Twitter</a></li>
                <li><a href="#." class="vimo"><i class="icon-vimeo3"></i> Vimeo</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php }?> 





    </div>
    <!-- <div class="row">
      <div class="col-md-12 text-center">
         <ul class="pager">
            <li><a href="#.">1</a></li>
            <li class="active"><a href="#.">2</a></li>
            <li><a href="#.">3</a></li>
        </ul>
      </div>
    </div> -->
  </div>
</section>
<!-- Latest Property Ends -->


<!--Deals-->
<section id="deal" class="featu_pro padding_top">
  <div class="container">
    <div class="row">
      <div class="col-sm-10">
        <h2 class="uppercase">Featured Properties</h2>
        <p class="heading_space">We have Properties in these Areas View a list of Featured Properties.</p>
      </div>
    </div>
    <div class="row">
      <div id="two-col-slider" class="owl-carousel">
        <?php 
       
        foreach ($defdata['home_prop1'] as $prop1){
          ?>
        <div class="item">
          <div class="listing_full">
          <div class="image">
            <img alt="image" src="<?= $assets."img/properties/".$prop1['prop_id'] ?>/cover.jpg" class="img-responsive">
              <?php if ($prop1['is_feat'] == "1")
              { 
                echo " <span class=\"tag_l\">Featured</span>";
              }
              if ($prop1['status'] == "sale")
              {
                 echo "<span class='tag_t'>For Sale</span>";
              }else if ($prop1['status'] == "rent")
              {
               echo " <span class=\"tag_t\">For Rent</span>";
              } 
              else if ($prop1['status'] == "rentd")
              {
               echo " <span class=\"tag_t\">Rented</span>";
              } 
              
              else if ($prop1['status'] == "sold")
              {
               echo " <span class=\"tag_t\">Sold</span>";
              }
              else if ($prop1['status'] == "rentd")
              {
               echo " <span class=\"tag_t\">Rented</span>";
              }
               else if ($prop1['status'] == "salag")
              {
                echo " <span class=\"tag_t\">Sale Agreed</span>";
              }
              else if ( $prop1['status'] == "rentag")
              {
                echo " <span class=\"tag_t\">Letting Agreed</span>";
              }
              ?>
           
            </div>
          </div>
         
          <div class="listing_full_bg">
            <div class="listing_inner_full">
              <span><a href="#"><i class="icon-like"></i></a></span>
              <a href="#.">
                <h3><?= $prop1['title'] ?></h3>
                <p><?= $prop1['address'] ?>, MR 21501</p>
              </a>
              <div class="favroute clearfix">
                <div class="property_meta"><span><i class="icon-select-an-objecto-tool"></i><?= $prop1['prop_details']['area'] ?> sq ft</span><span><i class=" icon-bed"></i><?= $prop1['prop_details']['bedrooms'] ?> Bedrooms</span><span><i class="icon-safety-shower"></i><?= $prop1['prop_details']['bathrooms'] ?> Bathrooms</span><span class="border-l"><?= $prop1['price'] ?>
                  <?php if ($prop1['status'] == 'rent' ||$prop1['status'] == 'rentd' || $prop1['status'] == 'rentag')
                  echo "pm"?>
                  

                </span></div>
              </div>
            </div>
          </div>
        </div>
         <?php  }  ?>
        </div>
        
      </div>
    </div>
  </div>
</section>
<!--Deals ends-->

<!-- Parallax Commented Out -->
<!-- <!--Parallax-->
<!-- <section id="parallax_four" class="padding">
  <div class="container">
    <div class="row">
      <div class="col-sm-8 bottom30">
        <h2>We Don’t Just Find <br> <span class="t_yellow">Great Deals</span> We Create Them</h2>
        <h4 class="top20">We are proud to present to you some of the best homes, apartments, offices e.g.
        across United Kingdom for affordable prices.</h4>
        <a href="#" class="text-uppercase btn-white top20">view all listings</a>

      </div>
    </div>
  </div>
</section> --> 
<!--About Owner ends-->



<!-- News Start -->
<section id="news-section-1" class="property-details bg_light padding_top">
   <div class="container property-details">
      <div class="row">
          <div class="col-md-12">
          <div class="bottom20 news_pro">
            <h2 class="uppercase">Latest News</h2>
          </div>
        </div>
        <div class="latest_news">
            <?php 
            //var_dump($feature_prop);
            
            foreach ($defdata['news'] as $news){ ?>
          <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="news_imgs la_im image-2">
                  <a href="news_detail?id=<?= $news['id']?>"><img src="<?php echo base_url('resources/img/news/'.$news['image_path']);?>" alt="image" class="img-responsive"/></a>
              <div class="clearfix"></div>
              </div>
              <div class="news-details lat_ne_aut">
                  <span>By <b><?= $news['author']?></b></span>
                <span><?php date('m ([ .\t-])* dd [,.stndrh\t ]+ y',strtotime($news['added_on']))?></span>
              </div>
              <div class="news_hdng">
                  <h5><a href="news_detail?id=<?= $news['id']?>"><?= $news['title']?></a></h5>
              </div>
              <div class="hom_news">
                  <p class="p-font-15"><?= $news['detail']?></p>
              </div>
          </div>
          <?php }?>
          <div class="col-md-12 text-center">
            <div class="bottom20 ltst_news_btn">
              <a href="news" class="btn btn-success">Read more</a>
            </div>
          </div>
        </div>
        
      </div>
   </div>
</section>
<!-- News End -->



<!--Partners-->
<section id="logos">
  <div class="container partner2 padding">
    <div class="row">
      <div class="col-sm-12 text-center">
        <h2 class="uppercase">Our Partners</h2>
        <p class="heading_space">Aliquam nec viverra erat. Aenean elit tellus mattis quis maximus.</p>
      </div>
    </div>
    <div class="row">
    <div id="partners" class="owl-carousel">
        <div class="item">
          <img src="<?= $assets ?>img/logo1.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo2.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo3.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo4.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo5.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo1.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo2.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo3.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo4.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo5.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo1.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo2.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo3.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo4.png" alt="Featured Partner">
        </div>
        <div class="item">
          <img src="<?= $assets ?>img/logo5.png" alt="Featured Partner">
        </div>
      </div>
    </div>
  </div>
</section>
<!--Partners Ends-->
<div class="container contacts">
  <div class="row">
    <div class="col-sm-4 text-center">
      <div class="info-box first">
        <div class="icons"><i class="icon-telephone114"></i></div>
        <ul class="text-center">
          <li><strong>Phone Number</strong></li>
          <li>(+44) 161 937 2059</li>
        </ul>
      </div>
    </div>
    <div class="col-sm-4 text-center">
      <div class="info-box">
        <div class="icons"><i class="icon-icons74"></i></div>
        <ul class="text-center">
          <li><strong>Favourite Move,</strong></li>
          <li>London, United Kingdom</li>
        </ul>
      </div>
    </div>
    <div class="col-sm-4 text-center">
      <div class="info-box">
        <div class="icons"><i class="icon-icons142"></i></div>
        <ul class="text-center">
          <li><strong>Email Address</strong></li>
          <li><a href="#.">info@favouritemove.com</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

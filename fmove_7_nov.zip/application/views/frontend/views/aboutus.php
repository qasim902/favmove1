
  <!-- Page Banner Start-->
  <section class="page-banner padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <h1 class="text-uppercase">About Us </h1>
          <p>Serving you since 1999. Lorem ipsum dolor sit amet consectetur adipiscing elit.</p>
          <ol class="breadcrumb text-center">
            <li><a href="#">Home</a></li>
            <li class="active">About Us</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <!-- Page Banner End -->

  <!-- About Us Start -->
  <section class="property-query-area">
    <div class="container">
      <div class="row">
        <div class="col-md-9">
          <div class="abt_us top10">
            <h2>About Us</h2>
            <br><br>
            <p class=" top10">Favorite Move is the UK's most comprehensive property website, focused on empowering users with the resources they need to make better-informed property decisions. We help consumers both find their next home and research the market by combining hundreds of thousands of property listings with market data, local information and community tools.</p>
            <p class=" top10">Favorite Move is the UK's most comprehensive property website, focused on empowering users with the resources they need to make better-informed property decisions. We help consumers both find their next home and research the market by combining hundreds of thousands of property listings with market data, local information and community tools.</p>
            <p class=" top10">Favorite Move is the UK's most comprehensive property website, focused on empowering users with the resources they need to make better-informed property decisions. We help consumers both find their next home and research the market by combining hundreds of thousands of property listings with market data, local information and community tools.</p>
            <p class=" top10">Favorite Move is the UK's most comprehensive property website, focused on empowering users with the resources they need to make better-informed property decisions. We help consumers both find their next home and research the market by combining hundreds of thousands of property listings with market data, local information and community tools.</p>
            
          </div>
        </div>


        <div class="col-sm-3 bottom10 top30">
            <aside class="col-md-12 col-xs- top30">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <a href="#">
                    <div class="image-2">
                      <img src="https://tpc.googlesyndication.com/simgad/15734968460721435892" alt="" class="img_ad" width="300" height="160" border="0">

                    </div>
                  </a>
                </div>
              </div>


            </aside>
        </div>


      </div>
    </div>
  </section>
  <!-- Property Search area End -->
<!-- <div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Property Add</h3>
            </div>
            <?php echo form_open('property/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="prop_details" class="control-label"><span class="text-danger">*</span>Prop Detail</label>
						<div class="form-group">
							<select name="prop_details" class="form-control">
								<option value="">select prop_detail</option>
								<?php 
								foreach($all_prop_details as $prop_detail)
								{
									$selected = ($prop_detail['property_id'] == $this->input->post('prop_details')) ? ' selected="selected"' : "";

									echo '<option value="'.$prop_detail['property_id'].'" '.$selected.'>'.$prop_detail['property_id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('prop_details');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="features" class="control-label"><span class="text-danger">*</span>Feature</label>
						<div class="form-group">
							<select name="features" class="form-control">
								<option value="">select feature</option>
								<?php 
								foreach($all_features as $feature)
								{
									$selected = ($feature['prop_id'] == $this->input->post('features')) ? ' selected="selected"' : "";

									echo '<option value="'.$feature['prop_id'].'" '.$selected.'>'.$feature['prop_id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('features');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="agent_id" class="control-label"><span class="text-danger">*</span>Agent</label>
						<div class="form-group">
							<select name="agent_id" class="form-control">
								<option value="">select agent</option>
								<?php 
								foreach($all_agents as $agent)
								{
									$selected = ($agent['id'] == $this->input->post('agent_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$agent['id'].'" '.$selected.'>'.$agent['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('agent_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="town_id" class="control-label">Uk Town</label>
						<div class="form-group">
							<select name="town_id" class="form-control">
								<option value="">select uk_town</option>
								<?php 
								foreach($all_uk_towns as $uk_town)
								{
									$selected = ($uk_town['id'] == $this->input->post('town_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$uk_town['id'].'" '.$selected.'>'.$uk_town['name'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('town_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="address" class="control-label"><span class="text-danger">*</span>Address</label>
						<div class="form-group">
							<input type="text" name="address" value="<?php echo $this->input->post('address'); ?>" class="form-control" id="address" />
							<span class="text-danger"><?php echo form_error('address');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="status" class="control-label">Status</label>
						<div class="form-group">
							<input type="text" name="status" value="<?php echo $this->input->post('status'); ?>" class="form-control" id="status" />
							<span class="text-danger"><?php echo form_error('status');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="video_embed" class="control-label">Video Embed</label>
						<div class="form-group">
							<input type="text" name="video_embed" value="<?php echo $this->input->post('video_embed'); ?>" class="form-control" id="video_embed" />
							<span class="text-danger"><?php echo form_error('video_embed');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="sold_on" class="control-label">Sold On</label>
						<div class="form-group">
							<input type="text" name="sold_on" value="<?php echo $this->input->post('sold_on'); ?>" class="form-control" id="sold_on" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_feat" class="control-label">Is Feat</label>
						<div class="form-group">
							<input type="text" name="is_feat" value="<?php echo $this->input->post('is_feat'); ?>" class="form-control" id="is_feat" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="price" class="control-label"><span class="text-danger">*</span>Price</label>
						<div class="form-group">
							<input type="text" name="price" value="<?php echo $this->input->post('price'); ?>" class="form-control" id="price" />
							<span class="text-danger"><?php echo form_error('price');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="description" class="control-label"><span class="text-danger">*</span>Description</label>
						<div class="form-group">
							<textarea name="description" class="form-control" id="description"><?php echo $this->input->post('description'); ?></textarea>
							<span class="text-danger"><?php echo form_error('description');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="property_images" class="control-label">Property Images</label>
						<div class="form-group">
							<textarea name="property_images" class="form-control" id="property_images"><?php echo $this->input->post('property_images'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div> -->

<!-- My Properties  -->
<div id="property" class="box box-info padding listing1">
    <div class="row">
        <div class="col-md-12 text-center">
            <ul class="f-p-links margin_bottom">
                <li><a href="profile.html"><i class="icon-icons230"></i>Profile</a></li>
                <li><a href="my_properties.html"><i class="icon-icons215"></i> My Properties</a></li>
                <li><a href="submit_property.html" class="active"><i class="icon-icons215"></i> Submit Property</a></li>
                <li><a href="favorite_properties.html"><i class="icon-icons43"></i> Favorite Properties</a></li>
                <li><a href="login.html"><i class="icon-lock-open3"></i>Logout</a></li>
            </ul>
        </div>
    </div>
    <div class="row">

        <div class="col-sm-1 col-md-2"></div>
        <div class="col-sm-10 col-md-8">
            <h2 class="text-uppercase bottom40">Add Your Property</h2>
            <form class="callus clearfix border_radius submit_property">
                <div class="row">
                    <div class="col-sm-6">

                        <div class="single-query form-group bottom20">
                            <label>Title</label>
                            <input type="text" class="keyword-input" placeholder="Enter your property title">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="single-query form-group bottom20">
                            <label>Location</label>
                            <input type="text" class="keyword-input" placeholder="Enter Proprty Location">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="single-query bottom20">
                            <label>Status </label>
                            <div class="intro">
                                <select>
                        <option class="active">For Sale</option>
                        <option>For Sale</option>
                        <option>For Sale </option>
                        <option>For Sale</option>
                        <option>For Rent</option>
                      </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="single-query form-group bottom20">
                            <label>Price</label>
                            <input type="text" class="keyword-input" placeholder="23,000">
                        </div>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="margin40 bottom15">Propertie Photos <i class="fa fa-info-circle help" data-toggle="tooltip" title="add images to upload for property!"></i></h3>



                    <div class="file_uploader bottom20">
                        <form id="upload-widget" method="post" action="/upload" class="dropzone">
                            <div class="dz-default dz-message">
                                <span>
      <i class="fa fa-plus-circle"></i>
      Click here or drop files to upload
      </span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="bottom15 margin40">Propertie Detail</h3>
                </div>
            </div>
            <form class="callus clearfix border_radius submit_property">
                <div class="row">

                    <div class="col-sm-4">

                        <div class="single-query form-group bottom20">
                            <label>Size Prefix</label>
                            <div class="intro">
                                <select>
                        <option class="active">Sq Ft</option>
                        <option>For Sale</option>
                        <option>For Sale </option>
                        <option>For Sale</option>
                        <option>For Rent</option>
                      </select>
                            </div>
                        </div>

                    </div>
                    <div class="col-sm-4">

                        <div class="single-query form-group bottom20">
                            <label>Bedrooms</label>
                            <div class="intro">
                                <select>
                        <option class="active">Number of Bedrooms</option>
                        <option>For Sale</option>
                        <option>For Sale </option>
                        <option>For Sale</option>
                        <option>For Rent</option>
                      </select>
                            </div>
                        </div>

                    </div>
                    <div class="col-sm-4">

                        <div class="single-query  form-group bottom20">
                            <label>Bathrooms</label>
                            <div class="intro">
                                <select>
                        <option class="active">Number of bathrooms</option>
                        <option>For Sale</option>
                        <option>For Sale </option>
                        <option>For Sale</option>
                        <option>For Rent</option>
                      </select>
                            </div>
                        </div>

                    </div>


                    <div class="col-sm-4">

                        <div class="single-query form-group bottom20">
                            <label>TV Lounge</label>
                            <div class="intro">
                                <select>
                        <option class="active">Number of TV Lounge</option>
                        <option>For Sale</option>
                        <option>For Sale </option>
                        <option>For Sale</option>
                        <option>For Rent</option>
                      </select>
                            </div>
                        </div>

                    </div>
                    <div class="col-sm-4">

                        <div class="single-query form-group  bottom20">
                            <label>Garages</label>
                            <div class="intro">
                                <select>
                        <option class="active">Number of Garages</option>
                        <option>For Sale</option>
                        <option>For Sale </option>
                        <option>For Sale</option>
                        <option>For Rent</option>
                      </select>
                            </div>
                        </div>

                    </div>
                    <div class="col-sm-4">

                        <div class="single-query form-group bottom20">
                            <label>Swimming Pool</label>
                            <div class="intro">
                                <select>
                        <option class="active">Number of Pool</option>
                        <option>For Sale</option>
                        <option>For Sale </option>
                        <option>For Sale</option>
                        <option>For Rent</option>
                      </select>
                            </div>
                        </div>

                    </div>
                    <div class="col-sm-12">
                        <h3 class="bottom15 margin40">Propertie Description </h3>
                        <textarea id="txtEditor"></textarea>
                    </div>
                    <div class="col-sm-12">
                        <h3 class="bottom15 margin40">Quick Summary</h3>
                        <div class="table-responsive summery_table">
                            <table class="table">
                                <tr>
                                    <td>
                                        <i class="fa fa-bars titles"></i>
                                    </td>
                                    <td>
                                        <div class="single-query form-group">
                                            <label>Title</label>
                                            <input type="text" class="keyword-input">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="single-query form-group">
                                            <label>Value</label>
                                            <input type="text" class="keyword-input">
                                        </div>
                                    </td>
                                    <td>
                                        <a href="#." class="close-t"><i class="fa fa-close"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <i class="fa fa-bars titles"></i>
                                    </td>
                                    <td>
                                        <div class="single-query form-group">
                                            <label>Title</label>
                                            <input type="text" class="keyword-input">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="single-query form-group">
                                            <label>Value</label>
                                            <input type="text" class="keyword-input">
                                        </div>
                                    </td>
                                    <td>
                                        <a href="#." class="close-t"><i class="fa fa-close"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <i class="fa fa-bars titles"></i>
                                    </td>
                                    <td>
                                        <div class="single-query form-group">
                                            <label>Title</label>
                                            <input type="text" class="keyword-input">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="single-query form-group">
                                            <label>Value</label>
                                            <input type="text" class="keyword-input">
                                        </div>
                                    </td>
                                    <td>
                                        <a href="#." class="close-t"><i class="fa fa-close"></i></a>
                                    </td>
                                </tr>

                            </table>
                            <a href="#." class="add-new"><i class="fa fa-plus"></i> Add New</a>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <h3 class="bottom15 margin40">Property Features</h3>
                        <div class="search-propertie-filters">
                            <div class="container-2">
                                <div class="row">
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="AC" />
                                            <span>Air Conditioning</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Balcony" />
                                            <span>Balcony</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Gas Heat" />
                                            <span>Gas Heat</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Fire Place" />
                                            <span>Fire Place</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="white">
                                            <input type="checkbox" name="Washer and Dryer" />
                                            <span>Washer and Dryer</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Swimming Pool" />
                                            <span>Swimming Pool</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Laundry Room" />
                                            <span>Laundry Room</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Home Theater" />
                                            <span>Home Theater</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Smoking allowed" />
                                            <span>Smoking allowed</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Cable TV" />
                                            <span>Cable TV</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class=" white">
                                            <input type="checkbox" name="Window Coverings" />
                                            <span>Window Coverings</span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <h3 class="bottom15 margin40">Video Presentation</h3>
                        <div class="single-query form-group bottom15">
                            <label>Vimeo or Youtube URL</label>
                            <input type="text" class="keyword-input" placeholder="https://vimeo.com">
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <h3 class="bottom15 margin40">Place on Map</h3>
                        <div class="single-query form-group bottom15">
                            <label>Property Address</label>
                            <input type="text" class="keyword-input" placeholder="Enter a Location">
                        </div>
                        <div id="single_map"></div>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn-blue border_radius margin40">submit property</button>
                    </div>

                </div>








            </form>


        </div>
        <div class="col-sm-1 col-md-2"></div>



        <div class="col-sm-4">





        </div>

    </div>

</div>
<!-- My Properties End -->
<script type="text/javascript" language="javascript">
    function myMap() {
      var mapCanvas = document.getElementById("single_map");
      var myCenter = new google.maps.LatLng(51.508742,-0.120850); 
      var mapOptions = {center: myCenter, zoom: 5};
      var map = new google.maps.Map(mapCanvas,mapOptions);
      var marker = new google.maps.Marker({
        position: myCenter,
        animation:google.maps.Animation.BOUNCE,
        icon: "img/map_marker.png"
      });
      marker.setMap(map);
    }
    
    </script>

<script type="text/javascript">
    $("#txtEditor").Editor();
    $('[data-toggle="tooltip"]').tooltip(); 
 </script>